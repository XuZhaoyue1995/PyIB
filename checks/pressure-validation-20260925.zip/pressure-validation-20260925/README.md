# PyIB pressure and runtime-load validation evidence

Author: Zhaoyue Xu. Prepared 2026-09-25.

This bundle contains measured GPU results for a sphere oscillating in quiescent fluid: radius 0.25, peak velocity 0.02, angular frequency 3.6, kinematic viscosity 0.05, density 1, Re0 = 0.2, R/delta = 1.5, and KC = 0.06981317. D32 uses 560 steps per period; D40 uses 700. Both simulations completed six periods. Grid spacing and time step change together, so this pair does not establish a separate spatial or temporal convergence order.

## Reproduce the numerical audit

Install Python 3 with NumPy, extract the archive, then run inside its directory:

```text
python check_pressure_validation.py . --output audit.json
```

The checker imports no PyIB module and runs no simulation. It verifies the file manifest, independently evaluates the analytic reference, recalculates pressure norms and pressure-force quadrature from the supplied per-marker CSVs, checks geometry and runtime force accounting, and fits the measured runtime force history. It compares these recalculations with the original measured results. The number of passing checks measures evidence consistency, not the number of independent physical benchmarks.

## Analytic reference and conventions

Let theta = omega t + phase; sphere velocity is U0 cos(theta) along unit vector e. Let delta = sqrt(2 nu / omega), k = R/delta, mu = rho nu, and lambda = (1+i)k. For the linear unbounded unsteady-Stokes solution:

```text
P_hat = mu U0 / (2R) * (3 + 3 lambda + lambda^2)
p_exact(n,t) = Re[P_hat exp(i theta)] * (n dot e)
F_hat = -6 pi mu R U0 * (1 + lambda + lambda^2/9)
F_exact(t) = Re[F_hat exp(i theta)] * e
```

The fluid-on-body load is `-force_fluid + interior_momentum_rate`; both terms and the resulting force are supplied in each runtime history. Pressure force is `-integral p n dA`. An area-weighted surface pressure mean is removed before discrete pressure-force quadrature to make it gauge invariant despite the finite marker quadrature's small normal-area closure defect.

The pressure error is `sqrt(sum_t sum_i A_i (p_i - p_exact_i)^2 / sum_t sum_i A_i p_exact_i^2)` using the four distinct quarter-period phases 5T, 5.25T, 5.5T, and 5.75T. The fifth field at 6T checks the repeated phase and is excluded from this aggregate. Raw and corrected pressures receive the same supplied additive gauge shift. That shift was calculated from volume fields in the exterior shell 4h to 6h; those large fields are not in this compact bundle. Their recorded SHA-256 hashes provide provenance, but the standalone checker cannot independently recover those gauge constants or rerun the volume pressure reconstruction.

Force coefficients are fitted by least squares to `a cos(theta) + b sin(theta) + c` over the final two periods, 4T < t <= 6T. The reported harmonic-vector error is `norm([a,b] - [a_exact,b_exact]) / norm([a_exact,b_exact])`; it includes amplitude and phase discrepancy. It is a different norm from the surface pressure error.

## Measured result and scope

| Quantity | D32 | D40 |
|---|---:|---:|
| Corrected surface pressure, relative area/time L2 | 2.5300% | 2.2224% |
| Runtime body force, harmonic-vector error | 5.2690% | 4.1190% |
| Cycle-to-cycle force waveform RMS / reference amplitude | 0.034108% | 0.033814% |

The errors compare finite-Re, finite-domain numerical solutions against a low-Re, low-KC, unbounded-domain analytical reference. They demonstrate benchmark-specific performance. They do not establish accuracy for Re = 200, arbitrary geometries, other motion histories, or full-volume pressure. CPU/GPU implementation checks and package tests are reported separately by the distribution.

All archived surface data concern pressure only. The bundle makes no claim about integrated total surface traction. Original external simulation and analysis files are preserved outside this publication bundle; selection and original hashes are recorded in `provenance.json` and `phases.json`.
